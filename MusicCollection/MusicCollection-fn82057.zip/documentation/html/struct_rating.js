var struct_rating =
[
    [ "rating", "struct_rating.html#ad8be510752bf08aca8c8ef92fe9e11df", null ],
    [ "song_id", "struct_rating.html#ae2862f3bafc6b96796e401d27ec625bd", null ],
    [ "user_id", "struct_rating.html#aff59211cc911c2a276485fcf5d781d12", null ]
];