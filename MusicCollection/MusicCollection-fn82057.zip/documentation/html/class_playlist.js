var class_playlist =
[
    [ "Playlist", "class_playlist.html#aef38d55e42995be147977726350f3ada", null ],
    [ "~Playlist", "class_playlist.html#aacd9a69e347fc19a9a0787d7a7ce9df4", null ],
    [ "get_creator_id", "class_playlist.html#a71e41fb1340fc7c6a7836d55351ca467", null ],
    [ "get_name", "class_playlist.html#a65687688b11d2a68a83fb4352c3a7e28", null ],
    [ "get_songs", "class_playlist.html#a88aef41f4822e8831414faf1011b53e5", null ],
    [ "operator==", "class_playlist.html#aba8040faf6b9d9294fe5a277621ade99", null ],
    [ "print_all_songs", "class_playlist.html#a44e6beb82c23a6963adeace8957a4271", null ],
    [ "set_creator", "class_playlist.html#adb0373f13e7429ad3f2d820d899c8f4a", null ],
    [ "set_name", "class_playlist.html#a2a412926cbe8f4038603b9b48e1eb303", null ],
    [ "set_songs", "class_playlist.html#a41fc91d6979ed871c74055649ebe56aa", null ],
    [ "creator_id", "class_playlist.html#a417c6736c96d1a6ffdf879a56d6f5a49", null ],
    [ "name", "class_playlist.html#a6b06305db2f4b7bfadccd994665501cf", null ],
    [ "songs", "class_playlist.html#a2503942ce9aa5d1ef1c12f4cd37f1891", null ]
];