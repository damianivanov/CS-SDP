var searchData=
[
  ['name_65',['name',['../class_playlist.html#a6b06305db2f4b7bfadccd994665501cf',1,'Playlist::name()'],['../class_song.html#ac9a7a376f0428cf9d13574b4f014049a',1,'Song::name()']]]
];
