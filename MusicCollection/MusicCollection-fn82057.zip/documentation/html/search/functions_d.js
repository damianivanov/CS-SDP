var searchData=
[
  ['user_218',['User',['../class_user.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../class_user.html#a06a529d3e9f9f0a37891b940b97ce0c6',1,'User::User(std::string _username, std::string _password, std::string _fullname, std::string _birthday, std::string _id=&quot;&quot;, std::vector&lt; std::string &gt; _favorite_genres=std::vector&lt; std::string &gt;())']]],
  ['user_5finfo_219',['user_info',['../class_music_player.html#a3251f19c279a8a4a65a80544be0a63bb',1,'MusicPlayer']]]
];
