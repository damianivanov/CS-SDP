var searchData=
[
  ['song_5fid_248',['song_id',['../struct_rating.html#ae2862f3bafc6b96796e401d27ec625bd',1,'Rating']]],
  ['songs_249',['songs',['../class_context.html#a7d526db11c1aa237c3076eb82ac76060',1,'Context::songs()'],['../class_playlist.html#a2503942ce9aa5d1ef1c12f4cd37f1891',1,'Playlist::songs()']]],
  ['songs_5faddress_250',['songs_address',['../class_context.html#a1a142ee4a57308058fec07a33d2eccd3',1,'Context']]]
];
