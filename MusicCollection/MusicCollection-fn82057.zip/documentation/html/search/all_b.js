var searchData=
[
  ['music_20collection_61',['Music Collection',['../index.html',1,'']]],
  ['mp_62',['mp',['../class_repl.html#abc88fbb1390bfbe73649ac80d1bfb371',1,'Repl']]],
  ['musicplayer_63',['MusicPlayer',['../class_music_player.html',1,'MusicPlayer'],['../class_music_player.html#a157211d92ff78fe87fdef2bb77a2b5fa',1,'MusicPlayer::MusicPlayer()']]],
  ['my_5fplaylists_64',['my_playlists',['../class_music_player.html#a405555ed6ac4f0375734c1593b7efbab',1,'MusicPlayer']]]
];
