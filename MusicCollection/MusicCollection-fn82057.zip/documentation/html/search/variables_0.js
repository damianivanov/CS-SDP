var searchData=
[
  ['album_227',['album',['../class_song.html#ae4b8a43a8bc7d6ec3b824bb932080c71',1,'Song']]],
  ['artist_228',['artist',['../class_song.html#aafa16527b221f910c0bb43bcd9a4dab2',1,'Song']]]
];
