var searchData=
[
  ['change_5fbirthday_137',['change_birthday',['../class_music_player.html#aa9b1b0c5624eedcf5f7ce1c335fb8a00',1,'MusicPlayer']]],
  ['change_5ffullname_138',['change_fullname',['../class_music_player.html#a62a45890377acf0b8fc587602b87ebd0',1,'MusicPlayer']]],
  ['change_5fpassword_139',['change_password',['../class_music_player.html#a0b285aed7845099ac6f72851b0b6b986',1,'MusicPlayer']]],
  ['change_5fusername_140',['change_username',['../class_music_player.html#a815ab622e884d9ba6e6a5fdf3bbbdbe8',1,'MusicPlayer']]],
  ['context_141',['Context',['../class_context.html#a652cdcd2eedc8dbd9110bd284c5d5cf0',1,'Context']]],
  ['create_5fsong_142',['create_song',['../class_music_player.html#a9feb1094792f5a1adc4072dc7b9897d3',1,'MusicPlayer']]]
];
