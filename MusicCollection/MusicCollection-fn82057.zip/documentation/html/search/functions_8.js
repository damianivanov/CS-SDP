var searchData=
[
  ['musicplayer_181',['MusicPlayer',['../class_music_player.html#a157211d92ff78fe87fdef2bb77a2b5fa',1,'MusicPlayer']]],
  ['my_5fplaylists_182',['my_playlists',['../class_music_player.html#a405555ed6ac4f0375734c1593b7efbab',1,'MusicPlayer']]]
];
