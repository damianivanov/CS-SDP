var searchData=
[
  ['user_111',['User',['../class_user.html',1,'User'],['../class_user.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../class_user.html#a06a529d3e9f9f0a37891b940b97ce0c6',1,'User::User(std::string _username, std::string _password, std::string _fullname, std::string _birthday, std::string _id=&quot;&quot;, std::vector&lt; std::string &gt; _favorite_genres=std::vector&lt; std::string &gt;())'],['../class_music_player.html#abc445f4327935ed351422a4be19fd113',1,'MusicPlayer::user()']]],
  ['user_5fid_112',['user_id',['../struct_rating.html#aff59211cc911c2a276485fcf5d781d12',1,'Rating']]],
  ['user_5finfo_113',['user_info',['../class_music_player.html#a3251f19c279a8a4a65a80544be0a63bb',1,'MusicPlayer']]],
  ['username_114',['username',['../class_user.html#aacbb807e514280f69e00bec7d71f3aee',1,'User']]],
  ['users_115',['users',['../class_context.html#a9cadf85d53a803dbc87a0adcf71d5288',1,'Context']]],
  ['users_5faddress_116',['users_address',['../class_context.html#a7012ead4fea59c5fe29dfd74b081d6fd',1,'Context']]]
];
