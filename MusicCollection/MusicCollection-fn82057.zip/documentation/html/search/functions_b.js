var searchData=
[
  ['rate_5fsong_190',['rate_song',['../class_music_player.html#a5609227b2b2e53c584bb5cd32e00d2f4',1,'MusicPlayer']]],
  ['rated_5fsong_191',['rated_song',['../class_context.html#a6e9a595098101e5b4a7d6bdea88cfe97',1,'Context']]],
  ['register_192',['Register',['../class_music_player.html#a0ba79f55e7a990fbdacc49eb23c503cf',1,'MusicPlayer']]],
  ['remove_5ffavorite_5fgenre_193',['remove_favorite_genre',['../class_music_player.html#ac8607d3319613f4f32cd2d676b258db2',1,'MusicPlayer::remove_favorite_genre()'],['../class_user.html#a659387a06ae85e85b8c19a8597556ce2',1,'User::remove_favorite_genre()']]],
  ['repl_194',['Repl',['../class_repl.html#aad6781d83d638c2b5d9bcad9c37c1f4c',1,'Repl']]],
  ['run_195',['run',['../class_repl.html#a569ab644866df5d0e5e5c574015811d1',1,'Repl']]]
];
