var searchData=
[
  ['change_5fbirthday_9',['change_birthday',['../class_music_player.html#aa9b1b0c5624eedcf5f7ce1c335fb8a00',1,'MusicPlayer']]],
  ['change_5ffullname_10',['change_fullname',['../class_music_player.html#a62a45890377acf0b8fc587602b87ebd0',1,'MusicPlayer']]],
  ['change_5fpassword_11',['change_password',['../class_music_player.html#a0b285aed7845099ac6f72851b0b6b986',1,'MusicPlayer']]],
  ['change_5fusername_12',['change_username',['../class_music_player.html#a815ab622e884d9ba6e6a5fdf3bbbdbe8',1,'MusicPlayer']]],
  ['context_13',['Context',['../class_context.html',1,'Context'],['../class_context.html#a652cdcd2eedc8dbd9110bd284c5d5cf0',1,'Context::Context()']]],
  ['create_5fsong_14',['create_song',['../class_music_player.html#a9feb1094792f5a1adc4072dc7b9897d3',1,'MusicPlayer']]],
  ['creator_5fid_15',['creator_id',['../class_playlist.html#a417c6736c96d1a6ffdf879a56d6f5a49',1,'Playlist']]]
];
