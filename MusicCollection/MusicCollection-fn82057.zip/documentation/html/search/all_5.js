var searchData=
[
  ['favorite_5fgenres_19',['favorite_genres',['../class_user.html#a353ccf0e6f1422de2173c508e46da496',1,'User']]],
  ['fill_20',['fill',['../class_music_player.html#a7e75df53fd01d8152f5b53af6f56e7e8',1,'MusicPlayer']]],
  ['filter_21',['filter',['../class_music_player.html#ae3261a88b920fa7b3680dc2369085adf',1,'MusicPlayer']]],
  ['formating_5fspaces_22',['formating_spaces',['../class_context.html#aab2f10a0a6e48c243d8b935d6290fa76',1,'Context']]],
  ['fullname_23',['fullname',['../class_user.html#aa37f981a564b92cb131a4e62e2bd53df',1,'User']]]
];
