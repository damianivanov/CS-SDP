var searchData=
[
  ['favorite_5fgenres_232',['favorite_genres',['../class_user.html#a353ccf0e6f1422de2173c508e46da496',1,'User']]],
  ['formating_5fspaces_233',['formating_spaces',['../class_context.html#aab2f10a0a6e48c243d8b935d6290fa76',1,'Context']]],
  ['fullname_234',['fullname',['../class_user.html#aa37f981a564b92cb131a4e62e2bd53df',1,'User']]]
];
