var searchData=
[
  ['genre_235',['genre',['../class_song.html#a29e5100b4f5448bf9ca988da683d9136',1,'Song']]]
];
