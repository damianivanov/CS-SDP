var searchData=
[
  ['add_5ffavorite_5fgenre_131',['add_favorite_genre',['../class_music_player.html#a71bce6631866522465f29a81b017c87a',1,'MusicPlayer::add_favorite_genre()'],['../class_user.html#a9c8e586b1153d4a25c004ac3de4129f6',1,'User::add_favorite_genre()']]],
  ['add_5fplaylist_132',['add_playlist',['../class_context.html#a8401c84e112fd5e11db2ad1528d66af5',1,'Context']]],
  ['add_5frating_133',['add_rating',['../class_context.html#a74dde706ef053a304bd586c7d8141722',1,'Context']]],
  ['add_5fsong_134',['add_song',['../class_context.html#a1095036cec434b0c0fada30884adf863',1,'Context']]],
  ['add_5fuser_135',['add_user',['../class_context.html#aebb507217c892c3186924e0acb7857d1',1,'Context']]],
  ['available_5fusername_136',['available_username',['../class_context.html#a2be7bfb3912f76d9b7c17a6fd7df5c73',1,'Context']]]
];
