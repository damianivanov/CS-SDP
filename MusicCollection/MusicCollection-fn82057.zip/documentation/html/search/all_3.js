var searchData=
[
  ['db_16',['db',['../class_music_player.html#a68d63846b51a8d52e58db4e4ff18dee5',1,'MusicPlayer']]],
  ['deserialization_17',['Deserialization',['../class_context.html#a1999ac108c83c689d709df9289fedbe0',1,'Context']]]
];
