var searchData=
[
  ['json_226',['json',['../_database_context_8h.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json():&#160;DatabaseContext.h'],['../_music_collection_8cpp.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json():&#160;MusicCollection.cpp']]]
];
