var searchData=
[
  ['add_5ffavorite_5fgenre_0',['add_favorite_genre',['../class_music_player.html#a71bce6631866522465f29a81b017c87a',1,'MusicPlayer::add_favorite_genre()'],['../class_user.html#a9c8e586b1153d4a25c004ac3de4129f6',1,'User::add_favorite_genre()']]],
  ['add_5fplaylist_1',['add_playlist',['../class_context.html#a8401c84e112fd5e11db2ad1528d66af5',1,'Context']]],
  ['add_5frating_2',['add_rating',['../class_context.html#a74dde706ef053a304bd586c7d8141722',1,'Context']]],
  ['add_5fsong_3',['add_song',['../class_context.html#a1095036cec434b0c0fada30884adf863',1,'Context']]],
  ['add_5fuser_4',['add_user',['../class_context.html#aebb507217c892c3186924e0acb7857d1',1,'Context']]],
  ['album_5',['album',['../class_song.html#ae4b8a43a8bc7d6ec3b824bb932080c71',1,'Song']]],
  ['artist_6',['artist',['../class_song.html#aafa16527b221f910c0bb43bcd9a4dab2',1,'Song']]],
  ['available_5fusername_7',['available_username',['../class_context.html#a2be7bfb3912f76d9b7c17a6fd7df5c73',1,'Context']]]
];
