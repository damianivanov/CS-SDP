var files_dup =
[
    [ "DatabaseContext.cpp", "_database_context_8cpp.html", "_database_context_8cpp" ],
    [ "DatabaseContext.h", "_database_context_8h.html", "_database_context_8h" ],
    [ "Guid.h", "_guid_8h.html", null ],
    [ "MusicCollection.cpp", "_music_collection_8cpp.html", "_music_collection_8cpp" ],
    [ "MusicPlayer.cpp", "_music_player_8cpp.html", null ],
    [ "MusicPlayer.h", "_music_player_8h.html", [
      [ "MusicPlayer", "class_music_player.html", "class_music_player" ]
    ] ],
    [ "Playlist.cpp", "_playlist_8cpp.html", null ],
    [ "Playlist.h", "_playlist_8h.html", [
      [ "Playlist", "class_playlist.html", "class_playlist" ]
    ] ],
    [ "Rating.h", "_rating_8h.html", [
      [ "Rating", "struct_rating.html", "struct_rating" ]
    ] ],
    [ "Repl.cpp", "_repl_8cpp.html", null ],
    [ "Repl.h", "_repl_8h.html", [
      [ "Repl", "class_repl.html", "class_repl" ]
    ] ],
    [ "sha3.h", "sha3_8h.html", null ],
    [ "Song.cpp", "_song_8cpp.html", null ],
    [ "Song.h", "_song_8h.html", [
      [ "Song", "class_song.html", "class_song" ]
    ] ],
    [ "User.cpp", "_user_8cpp.html", null ],
    [ "User.h", "_user_8h.html", [
      [ "User", "class_user.html", "class_user" ]
    ] ]
];