var annotated_dup =
[
    [ "Context", "class_context.html", "class_context" ],
    [ "MusicPlayer", "class_music_player.html", "class_music_player" ],
    [ "Playlist", "class_playlist.html", "class_playlist" ],
    [ "Rating", "struct_rating.html", "struct_rating" ],
    [ "Repl", "class_repl.html", "class_repl" ],
    [ "Song", "class_song.html", "class_song" ],
    [ "User", "class_user.html", "class_user" ]
];