var _music_collection_8cpp =
[
    [ "json", "_music_collection_8cpp.html#ab701e3ac61a85b337ec5c1abaad6742d", null ],
    [ "main", "_music_collection_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];